﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("OnlineEditorsExample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ascensio System SIA")]
[assembly: AssemblyProduct("OnlineEditorsExample")]
[assembly: AssemblyCopyright("Ascensio System SIA 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("3d5900ae-111a-45be-96b3-d9e4606ca793")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
